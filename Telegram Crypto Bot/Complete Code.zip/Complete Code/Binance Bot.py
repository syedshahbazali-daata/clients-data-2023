import binance
from binance.enums import *
from binance.client import Client

# Replace with your Binance API key and secret key
api_key = ''
api_secret = ''

# Connect to the Binance API
binance_client = Client(api_key, api_secret)

print("Client Created")

# current price of STORJ
price = binance_client.get_symbol_ticker(symbol='STORJUSDT')
print(price)

print("API Connected")

binance_client.futures_create_order(
    symbol='BTCUSDT',
    type='LIMIT',
    timeInForce='GTC',  # Can be changed - see link to API doc below
    price=30000,  # The price at which you wish to buy/sell, float
    side='BUY',  # Direction ('BUY' / 'SELL'), string
    quantity=0.001  # Number of coins you wish to buy / sell, float
)
print("Order Placed")
