"""
username = baldo
password = AVNS_31sHK4CCPIr6p4Ifgzd
host = db-mysql-nyc1-47136-do-user-12226124-0.b.db.ondigitalocean.com
port = 25060
database = Baldo
sslmode = REQUIRED
"""

import os
import time, csv
from datetime import datetime

import pyautogui
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
import undetected_chromedriver as uc
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


########################################################################################################################
# Functions

def get_file_data(file_name):
    with open(file_name, 'r', encoding='utf-8') as file:
        data = file.read().strip().split('\n')
    return data


def find_element_send_text(ele, text, clear=True):
    while True:
        try:
            input_field = driver.find_element(By.XPATH, ele)
            if clear:
                input_field.clear()
            input_field.send_keys(text)

            break
        except:
            time.sleep(0.1)


def specific_clicker(ele):
    while True:
        try:
            element = driver.find_element(By.XPATH, ele)
            webdriver.ActionChains(driver).move_to_element_with_offset(element, 1, 0).click(element).perform()

            break
        except Exception as e:
            # print(e)
            pass


def specific_clicker2(ele):
    try:
        element = driver.find_element(By.XPATH, ele)
        webdriver.ActionChains(driver).move_to_element_with_offset(element, 1, 0).click(element).perform()

    except Exception as e:
        # print(e)
        pass


def get_text(ele):
    while True:
        try:
            element = driver.find_elements(By.XPATH, ele)
            texts = [str(x.text) for x in element]
            return texts
        except Exception as e:
            # print(e)
            pass


def close_chrome():
    import os
    try:
        os.system("taskkill /im chrome.exe /f")
    except:
        pass

def data_scraper(search_term):
    url = ""
    driver.get(url)
    time.sleep(1)

    specific_clicker("//button[@class='btn btn-primary']")
    time.sleep(1)
    data = []
    for i in range(1, 100):
        try:
            data.append(get_text(f"//div[@class='col-md-12']//div[{i}]//div[@class='card-body']//h5"))
        except:
            break
    return data



import mysql.connector

connection = mysql.connector.connect(
    user='baldo',
    password='AVNS_31sHK4CCPIr6p4Ifgzd',
    host='db-mysql-nyc1-47136-do-user-12226124-0.b.db.ondigitalocean.com',
    port=25060,
    database='Baldo',

)

cursor = connection.cursor()

# Database is Connected Successfully
print("Database is connected successfully")

options = uc.ChromeOptions()
# path = r"C:\Users\user\AppData\Local\Google\Chrome\User Data"
# using os
path = os.path.join(os.environ['USERPROFILE'], 'AppData', 'Local', 'Google', 'Chrome', 'User Data')
options.add_argument(fr"user-data-dir={path}")
options.add_argument(f'--profile-directory=Default')
driver = uc.Chrome(options=options)

driver.get("https://holabaldo.com/wp-admin/")
input("Login to Holabaldo.com and press Enter to continue: ")

zip_code = data_scraper("10010")
for single_zip in zip_code:

    driver.get("https://holabaldo.com/wp-admin/post-new.php?post_type=page")

    name = single_zip[0]
    address = single_zip[1]
    phone = single_zip[2]
    description = single_zip[3]
    images = single_zip[4]
    url = single_zip[5]

    find_element_send_text("//input[@id='title']", name)
    find_element_send_text("//textarea[@id='content']", description)
    find_element_send_text("//input[@id='acf-field_5f9b2b0b0c0c0']", address)
    find_element_send_text("//input[@id='acf-field_5f9b2b0b0c0c1']", phone)
    find_element_send_text("//input[@id='acf-field_5f9b2b0b0c0c2']", url)

    # add images
    specific_clicker("//button[@id='acf-field_5f9b2b0b0c0c3-add']")
    time.sleep(1)
    for image in images:
        pyautogui.write(image)
        pyautogui.press("enter")
        time.sleep(1)

    specific_clicker("//button[@id='publish']")


driver.quit()

